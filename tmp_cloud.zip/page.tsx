import Link from "next/link";
import CloudChat from "./CloudChat";

type CloudPageProps = {
  params?: Promise<{
    id?: string;
  }>;
};

function BackIcon() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 18 8 12l7-6" />
    </svg>
  );
}

export default async function CloudPage({ params }: CloudPageProps) {
  const resolvedParams = (await params) ?? {};
  const cloudId = resolvedParams.id ?? "unknown";

  return (
    <div className="fixed inset-0 flex flex-col bg-black text-white">
      <div className="absolute left-4 top-4 z-10">
        <Link
          href="/"
          aria-label="Voltar à home"
          className="flex h-9 w-9 items-center justify-center text-white/70 transition hover:text-white"
        >
          <BackIcon />
        </Link>
      </div>
      <div className="flex-1 overflow-hidden">
        <CloudChat cloudId={cloudId} />
      </div>
    </div>
  );
}
